import { useState } from 'react'
import InputNumero from './components/InputNumero'
import BotonOperacion from './components/BotonOperacion'
import Resultado from './components/Resultado'
import Historial from './components/Historial'

const OPERACIONES = [
  { simbolo: '+', nombre: 'Suma', color: 'primary', calcular: (a, b) => a + b },
  { simbolo: '−', nombre: 'Resta', color: 'warning', calcular: (a, b) => a - b },
  { simbolo: '×', nombre: 'Multiplicación', color: 'success', calcular: (a, b) => a * b },
  { simbolo: '÷', nombre: 'División', color: 'danger', calcular: (a, b) => a / b },
]

function App() {
  const [num1, setNum1] = useState('')
  const [num2, setNum2] = useState('')
  const [resultado, setResultado] = useState(null)
  const [error, setError] = useState('')
  const [historial, setHistorial] = useState([])

  const operar = (op) => {
    setError('')

    if (num1 === '' || num2 === '') {
      setResultado(null)
      setError('Debes ingresar ambos números.')
      return
    }

    const a = parseFloat(num1)
    const b = parseFloat(num2)

    if (op.simbolo === '÷' && b === 0) {
      setResultado(null)
      setError('No se puede dividir entre cero.')
      return
    }

    const res = Number(op.calcular(a, b).toFixed(6))
    setResultado(res)
    setHistorial([`${a} ${op.simbolo} ${b} = ${res}`, ...historial])
  }

  const limpiar = () => {
    setNum1('')
    setNum2('')
    setResultado(null)
    setError('')
  }

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-12 col-md-8 col-lg-6">
          <div className="card shadow">
            <div className="card-header bg-dark text-white text-center">
              <h1 className="h4 mb-0">Calculadora básica</h1>
            </div>
            <div className="card-body p-4">
              <InputNumero id="num1" etiqueta="Primer número" valor={num1} onCambio={setNum1} />
              <InputNumero id="num2" etiqueta="Segundo número" valor={num2} onCambio={setNum2} />

              <div className="row g-2">
                {OPERACIONES.map((op) => (
                  <div className="col-6 col-sm-3" key={op.nombre}>
                    <BotonOperacion
                      simbolo={op.simbolo}
                      nombre={op.nombre}
                      color={op.color}
                      onClick={() => operar(op)}
                    />
                  </div>
                ))}
              </div>

              <Resultado resultado={resultado} error={error} />

              <button className="btn btn-outline-secondary w-100 mt-3" onClick={limpiar}>
                Limpiar campos
              </button>
            </div>
          </div>

          <Historial items={historial} onLimpiar={() => setHistorial([])} />
        </div>
      </div>
    </div>
  )
}

export default App
