// Componente reutilizable: botón de una operación
function BotonOperacion({ simbolo, nombre, color, onClick }) {
  return (
    <button
      type="button"
      className={`btn btn-${color} btn-lg w-100`}
      onClick={onClick}
      title={nombre}
    >
      <span className="fs-3">{simbolo}</span>
      <div className="small">{nombre}</div>
    </button>
  )
}

export default BotonOperacion
