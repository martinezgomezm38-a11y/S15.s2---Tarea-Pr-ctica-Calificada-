// Componente que lista las operaciones realizadas
function Historial({ items, onLimpiar }) {
  if (items.length === 0) return null
  return (
    <div className="card shadow-sm mt-4">
      <div className="card-header d-flex justify-content-between align-items-center">
        <strong>Historial</strong>
        <button className="btn btn-sm btn-outline-danger" onClick={onLimpiar}>
          Limpiar
        </button>
      </div>
      <ul className="list-group list-group-flush">
        {items.map((op, i) => (
          <li key={i} className="list-group-item">{op}</li>
        ))}
      </ul>
    </div>
  )
}

export default Historial
