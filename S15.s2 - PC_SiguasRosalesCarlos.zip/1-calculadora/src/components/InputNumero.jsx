// Componente reutilizable: campo numérico controlado
function InputNumero({ id, etiqueta, valor, onCambio }) {
  return (
    <div className="mb-3">
      <label htmlFor={id} className="form-label fw-semibold">{etiqueta}</label>
      <input
        id={id}
        type="number"
        className="form-control form-control-lg"
        placeholder="0"
        value={valor}
        onChange={(e) => onCambio(e.target.value)}
      />
    </div>
  )
}

export default InputNumero
