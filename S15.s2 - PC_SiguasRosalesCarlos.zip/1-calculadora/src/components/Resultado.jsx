// Componente que muestra el resultado o el error
function Resultado({ resultado, error }) {
  if (error) {
    return <div className="alert alert-danger mt-4 mb-0">{error}</div>
  }
  if (resultado === null) {
    return (
      <div className="alert alert-secondary mt-4 mb-0">
        Ingresa dos números y elige una operación.
      </div>
    )
  }
  return (
    <div className="alert alert-success mt-4 mb-0 text-center">
      <div className="small">Resultado</div>
      <div className="resultado-box">{resultado}</div>
    </div>
  )
}

export default Resultado
