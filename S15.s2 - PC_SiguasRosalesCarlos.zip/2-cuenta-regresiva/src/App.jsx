import { useState, useRef } from 'react'
import Contador from './components/Contador'

function App() {
  // Estado: fecha y título que se están contando
  const [fechaObjetivo, setFechaObjetivo] = useState('2026-12-25T00:00')
  const [titulo, setTitulo] = useState('Faltan para Navidad')

  // useRef: acceso directo a los campos del formulario
  const inputFecha = useRef(null)
  const inputTitulo = useRef(null)

  const aplicar = (e) => {
    e.preventDefault()
    if (!inputFecha.current.value) return
    setFechaObjetivo(inputFecha.current.value)
    setTitulo(inputTitulo.current.value || 'Cuenta regresiva')
  }

  return (
    <div className="container py-5">
      <h1 className="text-center mb-5">Cuenta regresiva</h1>

      <Contador fechaObjetivo={fechaObjetivo} titulo={titulo} />

      <div className="row justify-content-center mt-5">
        <div className="col-12 col-md-8 col-lg-6">
          <form className="card card-body shadow" onSubmit={aplicar}>
            <h3 className="h5 text-dark">Configurar fecha y hora</h3>

            <div className="mb-3">
              <label htmlFor="titulo" className="form-label text-dark">Título</label>
              <input
                id="titulo"
                ref={inputTitulo}
                type="text"
                className="form-control"
                defaultValue="Faltan para Navidad"
              />
            </div>

            <div className="mb-3">
              <label htmlFor="fecha" className="form-label text-dark">Fecha y hora</label>
              <input
                id="fecha"
                ref={inputFecha}
                type="datetime-local"
                className="form-control"
                defaultValue="2026-12-25T00:00"
              />
            </div>

            <button type="submit" className="btn btn-primary">Iniciar cuenta regresiva</button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default App
