// Muestra una unidad de tiempo (días, horas, minutos o segundos)
function CajaTiempo({ valor, etiqueta }) {
  return (
    <div className="caja-tiempo card bg-light text-dark text-center shadow">
      <div className="card-body py-3">
        <div className="numero">{String(valor).padStart(2, '0')}</div>
        <div className="text-muted mt-1">{etiqueta}</div>
      </div>
    </div>
  )
}

export default CajaTiempo
