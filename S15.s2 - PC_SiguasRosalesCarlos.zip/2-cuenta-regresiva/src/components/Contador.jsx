import useCuentaRegresiva from '../hooks/useCuentaRegresiva'
import CajaTiempo from './CajaTiempo'

function Contador({ fechaObjetivo, titulo }) {
  const { dias, horas, minutos, segundos, terminado } = useCuentaRegresiva(fechaObjetivo)

  return (
    <div className="text-center">
      <h2 className="h3 mb-1">{titulo}</h2>
      <p className="text-white-50 mb-4">
        {new Date(fechaObjetivo).toLocaleString('es-PE', {
          dateStyle: 'full',
          timeStyle: 'short',
        })}
      </p>

      {terminado ? (
        <div className="alert alert-success d-inline-block fs-4">
          ¡El tiempo ha terminado!
        </div>
      ) : (
        <div className="d-flex justify-content-center gap-2 gap-md-3 flex-wrap">
          <CajaTiempo valor={dias} etiqueta="Días" />
          <CajaTiempo valor={horas} etiqueta="Horas" />
          <CajaTiempo valor={minutos} etiqueta="Minutos" />
          <CajaTiempo valor={segundos} etiqueta="Segundos" />
        </div>
      )}
    </div>
  )
}

export default Contador
