import { useState, useEffect } from 'react'

// Calcula el tiempo restante entre ahora y la fecha objetivo
function calcular(fechaObjetivo) {
  const diferencia = new Date(fechaObjetivo).getTime() - Date.now()

  if (isNaN(diferencia) || diferencia <= 0) {
    return { dias: 0, horas: 0, minutos: 0, segundos: 0, terminado: true }
  }

  return {
    dias: Math.floor(diferencia / (1000 * 60 * 60 * 24)),
    horas: Math.floor((diferencia / (1000 * 60 * 60)) % 24),
    minutos: Math.floor((diferencia / (1000 * 60)) % 60),
    segundos: Math.floor((diferencia / 1000) % 60),
    terminado: false,
  }
}

// Hook personalizado: usa useState + useEffect
function useCuentaRegresiva(fechaObjetivo) {
  const [tiempo, setTiempo] = useState(() => calcular(fechaObjetivo))

  useEffect(() => {
    setTiempo(calcular(fechaObjetivo))

    const intervalo = setInterval(() => {
      setTiempo(calcular(fechaObjetivo))
    }, 1000)

    // Limpieza: evita fugas de memoria al desmontar o cambiar la fecha
    return () => clearInterval(intervalo)
  }, [fechaObjetivo])

  return tiempo
}

export default useCuentaRegresiva
