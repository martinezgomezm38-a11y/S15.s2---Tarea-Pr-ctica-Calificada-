import { useState, useEffect } from 'react'
import { obtenerPersonajes } from './services/personajesService'
import TarjetaPersonaje from './components/TarjetaPersonaje'
import Paginacion from './components/Paginacion'

function App() {
  const [personajes, setPersonajes] = useState([])
  const [pagina, setPagina] = useState(1)
  const [totalPaginas, setTotalPaginas] = useState(0)
  const [busqueda, setBusqueda] = useState('')
  const [nombre, setNombre] = useState('')
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState('')

  // Se ejecuta al cambiar la página o el filtro de nombre
  useEffect(() => {
    let activo = true
    setCargando(true)
    setError('')

    obtenerPersonajes(pagina, nombre)
      .then((datos) => {
        if (!activo) return
        setPersonajes(datos.results)
        setTotalPaginas(datos.info.pages)
      })
      .catch((err) => activo && setError(err.message))
      .finally(() => activo && setCargando(false))

    return () => { activo = false }
  }, [pagina, nombre])

  const buscar = (e) => {
    e.preventDefault()
    setPagina(1)
    setNombre(busqueda.trim())
  }

  return (
    <>
      <header className="bg-dark text-white py-4 mb-4">
        <div className="container">
          <h1 className="h3 mb-3">Personajes de Rick and Morty</h1>
          <form className="row g-2" onSubmit={buscar}>
            <div className="col-12 col-sm">
              <input
                type="text"
                className="form-control"
                placeholder="Buscar por nombre..."
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
              />
            </div>
            <div className="col-12 col-sm-auto">
              <button className="btn btn-primary w-100" type="submit">Buscar</button>
            </div>
          </form>
        </div>
      </header>

      <main className="container pb-5">
        {cargando && (
          <div className="text-center py-5">
            <div className="spinner-border text-primary" role="status" />
            <p className="mt-2">Cargando datos...</p>
          </div>
        )}

        {error && <div className="alert alert-danger">{error}</div>}

        {!cargando && !error && personajes.length === 0 && (
          <div className="alert alert-warning">No se encontraron personajes.</div>
        )}

        {!cargando && !error && (
          <div className="row g-4">
            {personajes.map((p) => (
              <div className="col-12 col-sm-6 col-md-4 col-lg-3" key={p.id}>
                <TarjetaPersonaje personaje={p} />
              </div>
            ))}
          </div>
        )}

        {!cargando && !error && (
          <Paginacion pagina={pagina} totalPaginas={totalPaginas} onCambiar={setPagina} />
        )}
      </main>
    </>
  )
}

export default App
