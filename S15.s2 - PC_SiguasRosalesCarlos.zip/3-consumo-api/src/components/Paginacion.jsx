function Paginacion({ pagina, totalPaginas, onCambiar }) {
  if (totalPaginas <= 1) return null
  return (
    <nav className="d-flex justify-content-center align-items-center gap-3 mt-4">
      <button
        className="btn btn-outline-dark"
        disabled={pagina === 1}
        onClick={() => onCambiar(pagina - 1)}
      >
        Anterior
      </button>
      <span>Página {pagina} de {totalPaginas}</span>
      <button
        className="btn btn-outline-dark"
        disabled={pagina === totalPaginas}
        onClick={() => onCambiar(pagina + 1)}
      >
        Siguiente
      </button>
    </nav>
  )
}

export default Paginacion
