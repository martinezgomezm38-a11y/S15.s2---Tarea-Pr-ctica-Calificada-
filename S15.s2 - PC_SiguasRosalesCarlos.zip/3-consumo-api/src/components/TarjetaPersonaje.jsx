const COLOR_ESTADO = { Alive: 'success', Dead: 'danger', unknown: 'secondary' }
const TEXTO_ESTADO = { Alive: 'Vivo', Dead: 'Muerto', unknown: 'Desconocido' }

function TarjetaPersonaje({ personaje }) {
  const { name, image, status, species, gender, origin, location } = personaje

  return (
    <div className="card h-100 shadow-sm">
      <img src={image} alt={name} className="card-img-top personaje-img" />
      <div className="card-body">
        <h5 className="card-title">{name}</h5>
        <span className={`badge bg-${COLOR_ESTADO[status] || 'secondary'} mb-2`}>
          {TEXTO_ESTADO[status] || status}
        </span>
        <ul className="list-unstyled small mb-0">
          <li><strong>Especie:</strong> {species}</li>
          <li><strong>Género:</strong> {gender}</li>
          <li><strong>Origen:</strong> {origin.name}</li>
          <li><strong>Ubicación:</strong> {location.name}</li>
        </ul>
      </div>
    </div>
  )
}

export default TarjetaPersonaje
