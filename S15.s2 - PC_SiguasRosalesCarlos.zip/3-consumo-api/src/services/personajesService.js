// Servicio que consume la API REST con Fetch API
const API_URL = 'https://rickandmortyapi.com/api/character'

export async function obtenerPersonajes(pagina = 1, nombre = '') {
  const url = `${API_URL}?page=${pagina}&name=${encodeURIComponent(nombre)}`
  const respuesta = await fetch(url)

  if (respuesta.status === 404) {
    // La API responde 404 cuando no hay coincidencias
    return { info: { pages: 0 }, results: [] }
  }
  if (!respuesta.ok) {
    throw new Error(`Error del servidor (${respuesta.status})`)
  }
  return respuesta.json() // { info: {...}, results: [...] }
}
