# Examen práctico de React

Tres proyectos hechos con Vite + React (JSX) + Bootstrap 5.

| Carpeta | Pregunta | Conceptos usados |
|---|---|---|
| 1-calculadora | Cuatro operaciones básicas | Componentes, props, useState, formularios controlados |
| 2-cuenta-regresiva | Cuenta regresiva a fecha y hora | useState, useEffect, useRef, hook personalizado |
| 3-consumo-api | Consumo de API REST con Bootstrap | Fetch API, useEffect, estados de carga/error, paginación |

## Cómo ejecutar cada proyecto

Requisito: Node.js 18 o superior.

```bash
cd 1-calculadora        # o 2-cuenta-regresiva, o 3-consumo-api
npm install
npm run dev
```

Abre la dirección que muestra la terminal (normalmente http://localhost:5173).
El proyecto 3 necesita conexión a internet (API: rickandmortyapi.com).
